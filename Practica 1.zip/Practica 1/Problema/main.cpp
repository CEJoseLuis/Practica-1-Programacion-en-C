#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    float p,g,h,diesel,a,d,v;
    float da,dd,pi;
    char fluido;
    da=997;
    dd=820;
    pi=3.1416;
    g=9.81;
    //Este es un programa que mide el volumen del recipiente, dado el valor del diametro y del liquido
    printf("Selecione el tipo de liquido con el que desea comezar: \n A para agua \n D para Diesel \n");
    scanf("%c",&fluido);
    
    a=(fluido=='A')?da:dd;
    
    printf("Ahora ingrese el valor del diametro:\n");
    scanf("%f",&d);
    
    printf("Ahora ingrese el valor de la presion hidrostatica:\n");
    scanf("%f",&p);
    
    v=((pi*d*d*p)/(4*a*g));    
    
  
    
    printf("El volumen es %f \n",v);
  
    
     
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
  
