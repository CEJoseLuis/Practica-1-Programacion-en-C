#include <stdio.h>
#include <stdlib.h>
#include <math.h>



int main(int argc, char *argv[]) {
	float radio,altura,lado,area,volumen,g;
	const float pi=3.1416;
	
	printf("\tEste programa puede calcular el volumen y area de un cono.\n\n");
	printf("A continuacion debe ingresar el radio y la altura y el programa\ncalculara\
 el area y el volumen:\n\n ");
	printf("Radio=");  scanf("%f",&radio);
	printf(" Altura="); scanf("%f",&altura);
	
	g=sqrt((altura*altura)+(radio*radio)); //sqrt es raiz cuadrada
	area=(2*pi*radio*g/2)+(pi*radio*radio);
	volumen=pi*radio*radio*altura/3;
	printf("El valor de g es igual a: %f",g);
	printf("\t\t\tVolumen=%.2f\n",volumen);
	printf("\t\t\tArea=%.2f\n\n",area);
	
	system("pause");
	return 0;
}
