#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	float grados;
	char letra;
	printf("Este programa puede convertir grados farenheit a centigrados y viceversa\n\
para ello debe ingresar una f al final si se trata de grados farenhei o una c\nsi se trata de grados celsius\n\n ");
	printf("\t\t\tGrados:"); scanf("%f %c",&grados,&letra);
	
	grados=(letra=='f' || letra=='F')?(grados=(grados-32)*5/9):(grados=grados);
	grados=(letra=='c' || letra=='C')?(grados=grados*(9/5)+32):(grados=grados);	
	
	letra=(letra=='c' || letra=='C')?(letra='F'):(letra='C');
	
	printf("\n\t\tEsto equivale a:%.3f %c\n\n\n",grados,letra);
	
	
	system("pause");
	return 0;
}
