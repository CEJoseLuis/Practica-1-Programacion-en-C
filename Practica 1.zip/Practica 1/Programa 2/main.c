#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float ft, yd, in, m, cm;
	printf("Este programa convierte pies(ft) en otras unidades de longitud\n \
	A continuacion ingrese la unidad a convertir: ");
	scanf("%f",&ft);
	
	m= ft*(0.3048);
	in=ft*(12);
	yd=ft*(0.3333333333);
	cm=m*(100);
	
	printf("Sus equivalencias son:\n  \t\t\tMetros=%.3f \n  \t\t\tPulgadas=%.4f \
	\n  \t\t\tYardas=%.4f\n  \t\t\tCentimetros=%.4f\n\n\t\t",m,in,yd,cm);
	system("pause");
	return 0;
}
