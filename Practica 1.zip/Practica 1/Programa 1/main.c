#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int x,y,a,b,res;
    printf("La operacion que se realizara\n es de la forma (x+y)*(x+y)*(a-b)\n");
    x=3;
    y=2;
    a=7;
    b=4;
    res=(x+y)*(x+y)*(a-b);
    printf("El resultado de la operacion es %i\n",res);
    
    printf("\t\tx=");
    scanf("%i",&x);
    
    printf("y=");
    scanf("%i",&y);
    
    printf("a=");
    scanf("%i",&a);
    
    printf("b=");
    scanf("%i",&b);
    
    res=(x+y)*(x+y)*(a-b);
    printf("El resultado de la operacion es %i\n",res);
    
  
  system("PAUSE");	
  return 0;
}
